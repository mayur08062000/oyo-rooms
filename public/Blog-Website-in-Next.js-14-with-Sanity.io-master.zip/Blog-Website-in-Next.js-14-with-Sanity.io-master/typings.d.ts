type Post = {
    title:string,
    summary:string,
    image:any,
    slug:string
}